/*
	Linked_List Class
*/
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
#include <stdlib.h>
#include <string>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include "node.h"

using namespace std;

class Linked_List {
private:
   unsigned int length; // the number of nodes contained in the list
   Node *head; // a pointer to the first node in the list
   int val;
public:
   Linked_List();
   ~Linked_List();
   int get_length();
   void create();
   bool end();
   void chooseorder();
   bool playagain();
   void addNode();
   Node* split(Node*);
   bool inorderd();
   int string_convert(string number);
   bool get_int(string prompt);
   void merge_sort(int, int, Linked_List*);
   int get_val(int);
   void set_node(int, int);
   void merge(int, int, int, Linked_List*);
   void deleteNode(Node*);
   // note: there is no set_length(unsigned int) (the reasoning should be intuitive)
   void print(); // output a list of all integers contained within the list
   void clear(); // delete the entire list (remove all nodes and reset length to 0)
   unsigned int push_front(int); // insert a new value at the front of the list (returns the new length of the list)
   unsigned int push_back(int); // insert a new value at the back of the list (returns the new length of the list)
   unsigned int insert(int val, unsigned int index); // insert a new value in the list at the specified index (returns the new length of the list)
   void swap(Node*, int);
   void sort_ascending(); // sort the nodes in ascending order. You must implement the recursive Merge Sort algorithm
   // Note: it's okay if sort_ascending() calls a recursive private function to perform the sorting.
   void sort_descending(int); // sort the nodes in descending order
   void print_primes();
   // you can add extra member variables or functions as desired
};
#endif