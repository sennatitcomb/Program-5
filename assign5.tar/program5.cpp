/******************************************************
** Program: program5.cpp
** Author: Senna Titcomb
** Date: 06/06/2020
** Description: A program that applies linked lists of signed integers. 
** The program will also count the number of prime numbers as well as be able to sort the linked list in ascending or descending order. 
** The user will be able to add integers to the linked list. 
** Input: integer value, y or n to keep entering values, d or a to choose the sort, 
** and y or n again to select whether the user wants to continue the program or not
** Output: the request for a number, the question if the user wants to keep entering, 
** the question of what sort the user prefers, the linked list values, the amount of prime numbers, 
** and the question of whether or not the user wants to continue the game
******************************************************/
#include <iostream>
#include <stdio.h>      /* printf, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>  
#include "linked_list.h"
#include "node.h"

using namespace std;

int main() {
    Linked_List l; //creates linked_list object
    bool play = true;
    while (play == true) { //while player wants to continue game
        l.create(); //starts program
        if (l.end() == false) {
            if (l.playagain() == true) { //if player wants to reset game
                play = true;
            } else {
                play = false; //ends program
            }
        } 
    }
	return 0;
}