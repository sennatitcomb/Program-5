/*
	Node Class
*/
#include <iostream>
#include "linked_list.h"
#include "node.h"

using namespace std;

/*************************************************************************************************************************************
** Function: Node() 
** Description: Default Node constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Node::Node() {
  //  cout << "Default Node constructor called" << endl;
    val = 0;
    next = NULL;

}

/*************************************************************************************************************************************
** Function: Node(int Val) 
** Description: Alternate Node constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Node::Node(int Val){
  //  cout << "Alternate Node constructor called" << endl;
    this->val = Val;
}

/*************************************************************************************************************************************
** Function: get_val() 
** Description: Accessor for value
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns value
*************************************************************************************************************************************/
int Node::get_val() {
    return this->val;
}

/*************************************************************************************************************************************
** Function: set_val() 
** Description: Mutator for value
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets value
*************************************************************************************************************************************/
void Node::set_val(int Val) {
    this->val = Val;
}

/*************************************************************************************************************************************
** Function: get_next() 
** Description: Accessor for next pointer
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns pointer
*************************************************************************************************************************************/
Node* Node::get_next() {
    return this->next;
}

/*************************************************************************************************************************************
** Function: set_next() 
** Description: Mutator for next pointer
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets pointer
*************************************************************************************************************************************/
void Node::set_next(Node* node) {
    this->next = node;
}

/*************************************************************************************************************************************
** Function: Node() 
** Description: Default Node constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Node::Node(Node* &node) {
  //  cout << "Default Node constructor called" << endl;
    val = node->get_val();
    next = node->get_next();

}