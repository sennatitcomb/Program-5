/*
	Linked_List Class
*/
#include <iostream>
#include "linked_list.h"


using namespace std;

/*************************************************************************************************************************************
** Function: Linked_List()
** Description: Default Linked_List constructor called
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Linked_List::Linked_List(){
  //  cout << "Default Linked_List constructor called" << endl;
    length = 0;
    val = 0;
    head = NULL;
     

}

/*************************************************************************************************************************************
** Function: push_front()
** Description: insert a new value at the front of the list 
** Parameters: int 
** Pre-conditions: int value is given
** Post-conditions: returns the new length of the list
*************************************************************************************************************************************/
unsigned int Linked_List::push_front(int Val) {
    Node* newNode = new Node;
    newNode->set_val(Val);
    newNode->set_next(NULL);
    if (head == NULL) {
        head = newNode;
    }else {
        Node* temp = head;
        head = newNode;
        head->set_next(temp);
    }
    length++;
    //delete newNode;
    return length;
} 

/*************************************************************************************************************************************
** Function: push_back()
** Description: insert a new value at the back of the list 
** Parameters: int 
** Pre-conditions: int value is given
** Post-conditions: returns the new length of the list
*************************************************************************************************************************************/
unsigned int Linked_List::push_back(int Val){
    Node* newNode = new Node;
    newNode->set_val(Val);
    newNode->set_next(NULL);
    if(head == NULL) {
        head = newNode;
        length++;
        return length;
    } 
    Node* current = head;
    while (current->get_next() != NULL) {
        current = current->get_next();
    }
    current->set_next(newNode);
    length++;
    //delete newNode;
    return length;
}

/*************************************************************************************************************************************
** Function: get_length()
** Description: Returns the length of the list
** Parameters: N/A 
** Pre-conditions: N/A
** Post-conditions: gives list length
*************************************************************************************************************************************/
int Linked_List::get_length() {
	return length;
}

/*************************************************************************************************************************************
** Function: string_convert()
** Description: Converts the string to an integer
** Parameters: string number
** Pre-conditions: take a string number
** Post-conditions: return the integer
*************************************************************************************************************************************/
int Linked_List::string_convert(string number) {
    int newNumber = 0;
    for (int x = 0; x < number.length(); x++) { 
        if (number[x] == 45) {
            x++;
        }
         newNumber += ((int) number[x] - 48) * pow(10, (number.length() - 1 - x));     
    }
    if (number[0] == 45) {
        newNumber = -1*newNumber; 
    }
    return newNumber;
}

/*************************************************************************************************************************************
** Function: get_int()
** Description: Takes a prompt from the user as a string literal, checks if input is a valid integer, returns the provided integer.
** Parameters: string prompt
** Pre-conditions: take a string parameter
** Post-conditions: return the provided integer.
*************************************************************************************************************************************/
bool Linked_List::get_int(string prompt) {
    for (int x = 0; x < prompt.length(); x++) {
        if (((int) prompt[x] < 48 || (int) prompt[x] > 57) && prompt[0] != 45) {
            return false;
        } 
    }

    return true;
}

/*************************************************************************************************************************************
** Function: create()
** Description: Asks user for input value
** Parameters: N/A 
** Pre-conditions: N/A
** Post-conditions: gives value to new node
*************************************************************************************************************************************/
void Linked_List::create() {
    string Val = "";
    cout << "Please enter a number: ";
    cin >> Val;
    if (get_int(Val) == true) {
        val = string_convert(Val);
        push_back(val);
        //push_front(val);
    } else {
        cout << "You did not enter a valid input." << endl;
        create();
    }
    
}

/*************************************************************************************************************************************
** Function: end()
** Description: Asks user if they want to continue adding numbers
** Parameters: N/A 
** Pre-conditions: N/A
** Post-conditions: continues program 
*************************************************************************************************************************************/
bool Linked_List::end() {
    string again = "";
    cout << "Do you want another number (y or n): ";
    cin >> again;
    if (again == "y") {
        return true;
    }else if (again == "n") {
        chooseorder();
        print_primes();
        return false;
    }else {
        cout << "You did not enter a valid choice. Please enter y or n." << endl;
        end();
    }
    return true;
}

/*************************************************************************************************************************************
** Function: chooseorder()
** Description: Asks user if they want to continue adding numbers
** Parameters: N/A 
** Pre-conditions: N/A
** Post-conditions: continues program 
*************************************************************************************************************************************/
void Linked_List::chooseorder() {
    string again = "";
    cout << "Do you want to sort ascending or descending (a or d): ";
    cin >> again;
    if (again == "a") {
        print();
        sort_ascending();
    }else if (again == "d") {
        print();
        sort_descending(length);
        cout << "Sorted Values: ";
        print();
    }else {
        cout << "You did not enter a valid choice. Please enter y or n." << endl;
        chooseorder();
    }
}

/*************************************************************************************************************************************
** Function: playagain()
** Description: Asks user for input value
** Parameters: N/A 
** Pre-conditions: N/A
** Post-conditions: gives value to new node
*************************************************************************************************************************************/
bool Linked_List::playagain() {
    string again = "";
    cout << "Do you want to do this again? (y or n): ";
    cin >> again;
    if (again == "y") {
        clear();
        return true;
    }else if (again == "n") {
        clear();
        return false;
        exit(0);
    }else {
        cout << "You did not enter a valid choice. Please enter y or n." << endl;
        clear();
        playagain();
    }
    return true;
}

/*************************************************************************************************************************************
** Function: print()
** Description: Prints out node values
** Parameters: N/A 
** Pre-conditions: N/A
** Post-conditions: Values are printed out
*************************************************************************************************************************************/
void Linked_List::print() {
    Node* current = head;
    while (current != NULL) {
        cout << current->get_val() << " ";
        current = current->get_next();
    }
    cout << endl;
}

/*************************************************************************************************************************************
** Function: clear()
** Description: delete the entire list 
** Parameters: N/A 
** Pre-conditions: N/A
** Post-conditions: Remove all nodes and reset length to 0
*************************************************************************************************************************************/
void Linked_List::clear() {
    Node* current = head;
    while (head!= NULL){
       current = head->get_next();
       delete head;
       head = current;
    }
    length = 0;
    val = 0;
    head = NULL;
}

/*************************************************************************************************************************************
** Function: insert()
** Description: insert a new value in the list at the specified index 
** Parameters: int val, unsigned int index 
** Pre-conditions: int val, unsigned int index
** Post-conditions: Returns the new length of the list
*************************************************************************************************************************************/
unsigned int Linked_List::insert(int val, unsigned int index) {
    Node* current = head;
    for (int i = 0; i < index; i++) {
        current = current->get_next();
    }
    current->set_val(val);
    return length;
}

/*************************************************************************************************************************************
** Function: swap()
** Description: swap nodes in list at the specified index 
** Parameters: Node* node, int index 
** Pre-conditions: int val, int index
** Post-conditions: Returns the new length of the list
*************************************************************************************************************************************/
//if this is over the max amount of lines it is because there are various cases this swap function adheres to
void Linked_List::swap(Node* node, int index) {
    Node* current = head;
    Node* before = head;
    Node* after = head;
    Node* beforecurrent;
    int count = 0;
    for (int i = 1; i < index; i++) {
        if (before->get_next() == node && count < 1) {
            count++;
        } else if (before->get_next() != node && count < 1){
            before = before->get_next();
        }
        beforecurrent = current;
        after = after->get_next();
        current = current->get_next();
    }

    if (node != NULL && current != NULL) {
        if (current == node) {
            //do nothing
        } else if (node == head) {
            head = current;
            if (node->get_next() == current) {
                node->set_next(current->get_next());
                current->set_next(node);
            } else {
                after = after->get_next();
                current->set_next(node->get_next());
                beforecurrent->set_next(node);
                node->set_next(after);
              //  cout << "H" << after->get_val() << endl;
               /*  cout << "H" << after->get_val() << endl;
                current->set_next(node->get_next());
                beforecurrent->set_next(node);
                cout << "H" << after->get_next()->get_val() << endl;
                node->set_next(after->get_next());
                cout << "I" << current->get_val() << endl; */
            } 
        /*} else if (beforecurrent == node) {
            cout << "JJJJJ" << endl;
            before->set_next(current);
            current->set_next(node);
            node->set_next(after->get_next());  */
        } else {
            //cout << "J" << current->get_val() << endl;
            before->set_next(current);
            //cout << "S" <<before->get_val()<< endl;
            //cout << "O" <<node->get_val()<< endl;
            beforecurrent->set_next(node);
            //cout << "B" <<beforecurrent->get_val()<< endl;
            node->set_next(after->get_next());
            //cout << "B" <<after->get_next()->get_val()<< endl;
            current->set_next(beforecurrent);
            //cout << "B" <<after->get_val()<< endl;
            //current->set_next(node->get_next());
            /*cout << "oc" << endl;
            if (index != length) {
                cout << "NO" << endl;
                cout << after->get_val() << endl;
                cout << after->get_next()->get_next()->get_val() << endl; */
                
           /* }else {
                cout << "HO" << endl;
                node->set_next(NULL);
            } */
        } 
    } 
    /*temp->set_next(current->get_next());
    current->set_next(node->get_next());
    node->set_next(temp->get_next()); */
}

/*************************************************************************************************************************************
** Function: deleteNode()
** Description: delete node in list at the specified index 
** Parameters: Node* node, int index 
** Pre-conditions: int val, int index
** Post-conditions: Returns the new length of the list
*************************************************************************************************************************************/
void Linked_List::deleteNode(Node* node) {
    Node* current = head;
    if (current == node) {
        head=(node->get_next());
        node = NULL;
    }else {
        while ((current->get_next() != node) && (current->get_next() != NULL)) {
        cout << "D" << endl;
        current = current->get_next();
        }
        cout << "E" << endl;
        current->set_next(node->get_next());
        cout << "F" << endl;
        node = NULL;
    }
    
    //temp->set_val(current->get_val());
    //current->set_val(node->get_val());
    //node->set_val(temp->get_val());
}

/*************************************************************************************************************************************
** Function: split()
** Description: Splits the list
** Parameters: Node* head1
** Pre-conditions: Node*
** Post-conditions: List is split
*************************************************************************************************************************************/
Node* Linked_List::split(Node* head1) {
     Node* current = head1;
     Node* head2;
     Node* head3;
     int i = 0;
    while (current != NULL) {
        current = current->get_next();
        i++;
    }
   current = head1;
    if(i != 1) {
        double sort1 = (i/2);
        for(int j = 0; j<sort1; j++) {
            cout << current->get_val() << endl;
            current = current->get_next();
        }
        head2 = current;
        head3 = head2->get_next();
        head2->set_next(NULL);
    } 

    Node* node = head;
    //mergesort(head1);
    return node;
}

/*************************************************************************************************************************************
** Function: merge_sort()
** Description: Merged lists and sorted
** Parameters: Node* head
** Pre-conditions: Node*
** Post-conditions: returns Node*
*************************************************************************************************************************************/
void Linked_List::merge_sort(int begin, int end, Linked_List* list) {
    if (begin < end) {
        int middle = begin+(end-begin)/2;
        merge_sort(begin, middle, list);
        merge_sort(middle+1, end, list);
        merge(begin, middle, end, list);
    }
}

/*************************************************************************************************************************************
** Function: get_val()
** Description: Gets value at index
** Parameters: int index
** Pre-conditions: int
** Post-conditions: returns Node*
*************************************************************************************************************************************/
int Linked_List::get_val(int index) {
    Node* temp = head;
    if (index < length) {
        for(int pos = 0; pos < index; pos++) {
            temp = temp->get_next();
        }
    }
    return temp->get_val();
}

/*************************************************************************************************************************************
** Function: set_node()
** Description: Replaces nodes
** Parameters: int index, int val
** Pre-conditions: int, int
** Post-conditions: replaces node
*************************************************************************************************************************************/
 void Linked_List::set_node(int index, int val) {
    if (index < length) {
        Node* current = head;
        for (int pos = 0; pos < index; pos++) {
            if (current->get_next() != NULL) {
                current = current->get_next();
            }
        }

        current->set_val(val);  
        /*if (current->get_next() != NULL) {
            Node* next = new Node(*current->get_next());
            current->set_next(node);
            node->set_next(next->get_next());
        }  */
        
  }
}  

/*************************************************************************************************************************************
** Function: merge()
** Description: Lists are merged 
** Parameters: int, int, int, Linked_List*
** Pre-conditions: int, int, int, Linked_List*
** Post-conditions: lists are merged
*************************************************************************************************************************************/
void Linked_List::merge(int l, int m, int r, Linked_List* list) {
    int Left = l;
    int Right = m+1;
    Linked_List* l1 = new Linked_List;
    while(Left <= m && Right <= r) {
        if (list->get_val(Left) <= list->get_val(Right)) {
            l1->push_back(list->get_val(Left));
            Left++;
        } else {
            l1->push_back(list->get_val(Right));
            Right++;
        }
    }
    while(Left <= m) {
        l1->push_back(list->get_val(Left));
        Left++;
    }
    while(Right <= r) {
        l1->push_back(list->get_val(Right));
        Right++;
    }
    for(int i = 0; i < r-l+1; i++) {
        //Node* node = new Node;
       // node->set_val(l1->get_val(i));
        list->set_node(l+i, l1->get_val(i));
    }
    l1->clear();
    delete l1;
  /*  cout << "yep" << endl;
   Node* current = head1;
   Node* temp = head1;
    while (current != NULL) {
        temp = temp->get_next();
        if(temp != NULL && (current->get_val() > temp->get_val())) {
            return current;
        } else if (temp != NULL && (current->get_val() < temp->get_val())) {
           return temp;
        }
        current = current->get_next();
    }
    return current; */
}

/*************************************************************************************************************************************
** Function: sort_ascending()
** Description: Sorts the list in ascending order
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: Returns the sorted list
*************************************************************************************************************************************/
void Linked_List::sort_ascending() {
    merge_sort(0, length-1, this);
   /* Node* node = head;
   // for(int i = 1; i < length; i++) {
        node->set_next(split(head));
        node = node->get_next();
    //} */
    cout << "Sorted Values: ";
    print(); 
}

/*************************************************************************************************************************************
** Function: sort_descending()
** Description: Sorts the list in descending order
** Parameters: int index
** Pre-conditions: int
** Post-conditions: Returns the sorted list
*************************************************************************************************************************************/
void Linked_List::sort_descending(int index) {
    Node* current = head;
    Node* temp;
    Node* small = head;
    int i = 1;
    while (current != NULL && i < index && (current->get_next()!= NULL)) {
        i++;
        temp = current->get_next();
        if(temp != NULL && (current->get_val() < temp->get_val())) {
            if (current->get_val() <= small->get_val()) {
                small = current;
            }
        } else if (temp != NULL && (current->get_val() > temp->get_val())) {
            if (temp->get_val() <= small->get_val()) {
                small = temp;
            }
        }
        current = current->get_next();
    } 
    if(inorderd() == false) {
        swap(small, index); //SWAPS POINTERS AT CERTAIN INDEX
        index--;
        sort_descending(index);
    }  
}

/*************************************************************************************************************************************
** Function: inorderd()
** Description: Checks if list is sorted
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: Returns true or false
*************************************************************************************************************************************/
bool Linked_List::inorderd() {
    Node* current = head;
    int count = 0;
    while (current != NULL && current->get_next() != NULL) {
        if (current->get_val() < current->get_next()->get_val()){
            count++;
        }
        current = current->get_next();
    }
    if (count > 0) {
        return false;
    }
    if (count == 0) {
        return true;
    }
    return true;
    cout << endl;
}


/*************************************************************************************************************************************
** Function: print_primes()
** Description: Counts the primes in the list
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns how many primes there are
*************************************************************************************************************************************/
void Linked_List::print_primes() {
    int count = 0;
    bool isPrime = true;
    Node* current = head;
    while(current != NULL) {
        bool done = false;
        if (current->get_val() == 2){
                isPrime = true;
                done = true;
        }
        if (!done && (current->get_val() <= 1 || current->get_val() % 2 == 0)) {
            isPrime = false;
            done = true;
        }
        if (!done) {
            for (int j = 3; j < (current->get_val()/2); j=j+2) {
                if (current->get_val() % j == 0) {
                    isPrime = false;
                    break;
                } 
            }
        }
        
        if (isPrime == true) {
            count++;
        } 
        current = current->get_next();
        isPrime = true;
    }
    cout << "You have " << count << " primes." << endl;
} 

/*************************************************************************************************************************************
** Function: ~Linked_List()
** Description: Default Linked_List Destructor called
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: destructs all variables
*************************************************************************************************************************************/
Linked_List::~Linked_List() {
   // cout << "Linked_List Destructor" << endl;
   Node* current = head;
   while (head!= NULL){
       current = head->get_next();
       delete head;
       head = current;
    }
}

/* cout << "A" << endl;
    Node** newArray = new Node*[++length];
     cout << "B" << endl;
    Node* temp = new Node;
     cout << "C" << endl;
    temp->set_val(Val);
     cout << "D" << endl;
    temp->set_next(NULL);
     cout << "E" << endl;
    if(head == NULL) {
         cout << "F" << endl;
        head = temp;
         cout << "G" << endl;
    } else {
         cout << "H" << endl;
        tail->set_next(temp);
         cout << "I" << endl;
        tail = temp;
         cout << "J" << endl;
    }
    newArray[length-1] = tail;
     cout << "A" << endl;
    for(int i = 0; i<length-1; i++) {
         cout << "A" << endl;
        newArray[i] = myArray[i];
         cout << "A" << endl;
    }
    if (length > 1) {
        delete [] myArray;
    }    
    
    else {
        double sort = i/2;
        for(int j = 0; j<sort; j++) {
            current = current->get_next();
        }
        Node* head1 = current;
        return i;
    } 

    Node* Linked_List::splitb(Node* head2) {
     Node* current = head2;
     int i = 0;
    while (current != NULL) {
        current = current->get_next();
        i++;
    }
   current = head2;
    if(i > 1) {
        double sort1 = (i/2);
        for(int j = 0; j<sort1; j++) {
            cout << current << endl;
            current = current->get_next();
        }
        Node* head1 = current;
        Node* head3 = head1->get_next();
        head1->set_next(NULL);
        mergesort(head1);
        Node* printer = head1;
        while (printer != NULL) {
            cout << printer->get_val() << " ";
            printer = printer->get_next();
        }
        cout << endl;
    } 
}
    
    */