/*
	Node Class
*/
#ifndef NODE_H
#define NODE_H

#include <iostream>

using namespace std;

class Node {
public:
   int val;    // the value that this node stores
   Node *next; // a pointer to the next node in the list
   Node();
   Node(int);
   Node(Node* &);
   int get_val();
   void set_val(int);
   Node* get_next();
   void set_next(Node*);
    
};
#endif

